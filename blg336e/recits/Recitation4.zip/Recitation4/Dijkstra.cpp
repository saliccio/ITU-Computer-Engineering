#include <iostream>
#include <queue>
#include <unordered_map>
#include <limits>
#include <algorithm>
using namespace std;

const int INF = numeric_limits<int>::max();

unordered_map<string, vector<pair<string, int>>> graph;

unordered_map<string, pair<int, string>> dijkstra(const string& source_node) {
    unordered_map<string, pair<int, string>> dists;
    for (const auto& node : graph) {
        dists[node.first] = { INF, "" };
    }
    dists[source_node] = { 0, "" };
    unordered_map<string, bool> visited;
    for (const auto& node : graph) {
        visited[node.first] = false;
    }

    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pQueue;
    pQueue.push({ 0, source_node });

    while (!pQueue.empty()) {
        int dist = pQueue.top().first;
        string current_node = pQueue.top().second;
        pQueue.pop();
        visited[current_node] = true;
        cout << "Exploring node " << current_node << " with distance " << dist << endl;
        for (const auto& neighbor_node : graph[current_node]) {
            string neighbor = neighbor_node.first;
            int edge_weight = neighbor_node.second;
            if (!visited[neighbor]) {
                string prev_node = dists[neighbor].second;
                int old_dist = dists[neighbor].first;
                int new_dist = dists[current_node].first + edge_weight;
                cout << "    Current shortest distance to " << neighbor << " is " << old_dist << " from node " << prev_node << endl;
                cout << "    New distance to " << neighbor << " via " << current_node << " is " << new_dist << endl;
                if (new_dist < old_dist) {
                    pQueue.push({ new_dist, neighbor });
                    dists[neighbor] = { new_dist, current_node };
                    cout << "    Updated shortest distance to " << neighbor << " via " << current_node << endl;
                }
            }
        }
    }
    return dists;
}

void print_path(unordered_map<string, pair<int, string>>& dijkstra_result, string source_node, string destination_node) {
    vector<string> path;
    string current_node = destination_node;
    while (current_node != source_node) {
        auto [distance, prev_node] = dijkstra_result[current_node];
        path.push_back("to " + current_node + " with total " + to_string(distance) + " km");
        current_node = prev_node;
    }
    path.push_back("starting from " + source_node);
    reverse(path.begin(), path.end());
    for (const auto& node : path) {
        cout << node << endl;
    }
}


int main() {
	
	string source_node;
	string destination_node;
	
	if(false){
		graph = {
			{ "s", { {"2", 9}, {"6", 14}, {"7", 15} } },
			{ "2", { {"3", 24} } },
			{ "3", { {"t", 19}, {"5", 2} } },
			{ "4", { {"3", 6}, {"t", 6} } },
			{ "5", { {"4", 11}, {"t", 16} } },
			{ "6", { {"3", 18}, {"5", 30}, {"7", 5} } },
			{ "7", { {"5", 20}, {"t", 44} } },
			{ "t", {} },
		};

		source_node = "s";
		destination_node = "t";
	}
	
	if(false){
		graph = {
			{ "A", { {"B", 5}, {"C", 2} } },
			{ "B", { {"C", -10} } },
			{ "C", {} },
		};

		source_node = "A";
		destination_node = "C";
	}
	
	if(true){
		graph = {
			{"06", {{"71", 75}, {"40", 184}, {"68", 225}}}, 
			{"71", {{"06", 75}, {"66", 140}, {"40", 113}}}, 
			{"40", {{"06", 184}, {"71", 113}, {"68", 110}, {"66", 112}, {"50", 91}}}, 
			{"68", {{"06", 225}, {"40", 110}, {"50", 75}, {"51", 123}}}, 
			{"66", {{"71", 140}, {"40", 112}, {"50", 190}, {"38", 175}, {"58", 224}}}, 
			{"50", {{"40", 91}, {"68", 75}, {"66", 190}, {"38", 81}, {"51", 82}}}, 
			{"51", {{"68", 123}, {"50", 82}, {"38", 128}, {"01", 205}}}, 
			{"38", {{"66", 175}, {"50", 81}, {"58", 194}, {"51", 128}, {"01", 333}, {"46", 273}}}, 
			{"58", {{"66", 224}, {"38", 194}, {"46", 339}, {"44", 246}}}, 
			{"46", {{"58", 339}, {"38", 273}, {"44", 220}, {"01", 192}, {"02", 164}, {"80", 105}, {"27", 76}}}, 
			{"44", {{"58", 246}, {"46", 220}, {"02", 182}}}, 
			{"01", {{"38", 333}, {"51", 205}, {"46", 192}, {"80", 87}}}, 
			{"02", {{"44", 182}, {"46", 164}, {"27", 150}, {"63", 110}}}, 
			{"80", {{"46", 105}, {"01", 87}, {"27", 125}}}, 
			{"27", {{"46", 76}, {"02", 150}, {"80", 125}, {"63", 137}}}, 
			{"63", {{"02", 110}, {"27", 137}}},
		};

		source_node = "06";
		destination_node = "63";
	}
    auto dijkstra_result = dijkstra(source_node);

    cout << "--------------" << endl;
    print_path(dijkstra_result, source_node, destination_node);

    return 0;
}
