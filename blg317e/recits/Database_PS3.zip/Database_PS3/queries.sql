-- SQLite

/*-----1. QUERY-----*/
/* CREATE DEALERS TABLE*/
CREATE TABLE DEALERS (
ID SERIAL PRIMARY KEY,
NAME VARCHAR(80) NOT NULL,
GENDER INTEGER,
MEM_YEAR NUMERIC(4),
MEM_TYPE INTEGER,
PHONE_NUM VARCHAR(80),
/*Add Constraint to the Table*/
CHECK ((GENDER >= 0) AND (GENDER <= 1)), 
CHECK ((MEM_YEAR >= 1900) AND (MEM_YEAR <= 2100)),
CHECK ((MEM_TYPE >= 0) AND (MEM_TYPE <= 3))
);

.tables #show table names

.header on 
.mode column
pragma table_info('DEALERS');



/*-----2. QUERY-----*/
/*CREATE SALECARS TABLE*/
CREATE TABLE SALECARS (
ID SERIAL PRIMARY KEY,
BRAND VARCHAR(80) NOT NULL,
MODEL VARCHAR(80),
YEAR NUMERIC(4),
KM INTEGER,
COLOR VARCHAR(80),
PRICE FLOAT,
CITY VARCHAR(80),
DEALER_ID INTEGER,
/*Add Constraint to the Table*/
CHECK ((YEAR >= 1900) AND (YEAR <= 2100)), 
/* Make DEALER_ID Foreign Key for SCALERS Table*/
FOREIGN KEY (DEALER_ID) REFERENCES DEALERS (ID)
);

/*-----3. QUERY-----*/
/*ADD PHONE NUMBER COLUMN TO DEALERS TABLE*/
ALTER TABLE DEALERS ADD COLUMN CITY VARCHAR(80);

/*-----4. QUERY-----*/
/*ROW INSERTION TO DEALERS TABLE*/
INSERT INTO DEALERS VALUES (
1113, 
'Robert', 
0, 
2016, 
2, 
5553333333, 
'Ankara');

INSERT INTO DEALERS (NAME, GENDER, MEM_YEAR, MEM_TYPE, PHONE_NUM, CITY) VALUES ('Robert',0,2016,2,5553333333,'Ankara');


/*-----5. QUERY-----*/
INSERT INTO DEALERS VALUES (1114, 'Mary', 1,	2019, 1, 5552222222, 'Antalya');
INSERT INTO DEALERS VALUES (1121, 'John', 0,	2014, 2, 5559999999, 'Bursa');
INSERT INTO DEALERS VALUES (1124, 'William', 0,	2021, 0, 5559999922, 'Duzce');
INSERT INTO DEALERS VALUES (1111, 'James', 0, 2012, 2, 5555555555, 'Istanbul');
INSERT INTO DEALERS VALUES (1112, 'Patricia', 1,	2009, 3, 5554444444, 'Istanbul');
INSERT INTO DEALERS VALUES (1122, 'Linda', 1, 2015, 2, 5559999900, 'Izmir');
INSERT INTO DEALERS VALUES (1115, 'John', 0,	2021, 0, 5551111111, 'Konya');
INSERT INTO DEALERS VALUES (1118, 'Linda', 1, 2018, 2, 5557777777, 'Malatya');
INSERT INTO DEALERS VALUES (1123, 'Jessica', 1, 2011, 3, 5559999911, 'Manisa');
INSERT INTO DEALERS VALUES (1117, 'Thomas', 0, 2020, 3, 5556666666, 'Mersin');
INSERT INTO DEALERS VALUES (1119, 'Matthew', 0, 2010, 3, 5558888888, 'Trabzon');
INSERT INTO DEALERS VALUES (1116, 'Patricia', 1,	2020, 0, 5550000000, 'Van');

/*-----6. QUERY-----*/
/*ROW INSERTION TO SALECARS TABLE*/
INSERT INTO SALECARS VALUES (
1,
'MERCEDES',
'cla',
2016,
9000,
'smoky',
143500.00,
'ANKARA',
1113
);

/*-----7. QUERY-----*/
INSERT INTO SALECARS VALUES (2, 'BMW', '520i', 2013, 95000, 'white', 135500.00, 'Ankara', 1113);
INSERT INTO SALECARS VALUES (3, 'ALFAROMEO',	'giulietta', 2012, 89000, 'white', 59750.00, 'Antalya', 1114);
INSERT INTO SALECARS VALUES (4, 'BMW', 'm6', 2013, 58000, 'navy blue', 64500.00, 'Bursa', 1121);
INSERT INTO SALECARS VALUES (5, 'VOLKSWAGEN', 'jetta', 2014,	114000,	'white', 58500.00,	'Duzce', 1124);
INSERT INTO SALECARS VALUES (6, 'BMW', 'm6',	2013, 58000, 'navy blue', 705000.00, 'Istanbul', 1111);
INSERT INTO SALECARS VALUES (7, 'BMW', 'm4',	2015, 11467, 'white', 525000.00, 'Istanbul', 1112);
INSERT INTO SALECARS VALUES (8, 'VOLKSWAGEN', 'passat', 2013, 90000,	'black', 91500.00, 'Istanbul', 1111);
INSERT INTO SALECARS VALUES (9, 'HONDA',	'accord', 2005, 239000,	'black', 33000.00, 'Istanbul', 1111);
INSERT INTO SALECARS VALUES (10, 'HONDA', 'civic', 2012,	51000, 'black',	56500.00, 'Izmir', 1122);
INSERT INTO SALECARS VALUES (11, 'MERCEDES',	'cla', 2013, 23000,	'silver gray', 107750.00, 'Konya', 1115);
INSERT INTO SALECARS VALUES (12, 'ALFAROMEO', 'brera', 2007,	90000, 'red', 90000.00,	'Malatya', 1118);
INSERT INTO SALECARS VALUES (13, 'VOLKSWAGEN', 'golf', 2013,	58000,	'claret', 55000.00,	'Manisa', 1123);
INSERT INTO SALECARS VALUES (14, 'ALFAROMEO', 'giulietta', 2014,	73000, 'red', 58000.00,	'Mersin', 1117);
INSERT INTO SALECARS VALUES (15, 'HONDA', 'civic', 2015,	51000, 'white',	74750.00, 'Trabzon', 1119);


/*-----8. QUERY-----*/
/* DELETE some rows according to a condition*/
DELETE FROM SALECARS WHERE ((KM > 50000) AND (YEAR < 2013));

/* !!!!!! DO NOT RUN IN THE ONLONE SESSION */
/* DROP Tables*/
DROP TABLE DEALERS;
DROP TABLE SALECARS;

/* DROP COLUMN*/
/* DROP COLUMN does not work for SQLite.
Firstly a new and same table should be created without constraint. Then 
the old one should be deleted and the name of the new table can be renamed.*/

/* SQLite supports a limited subset of ALTER TABLE. 
The ALTER TABLE command in SQLite allows the user to rename 
a table or add a new column to an existing table. 
It is not possible to rename a column, remove a column, 
or add or remove constraints from a table.*/


/* proof of work*/
INSERT INTO SALECARS VALUES (
16, 
'VOLKSWAGEN', 
'golf', 
2014, 
63000, 
'blue', 
94000.00, 
'Van', 
1116);
