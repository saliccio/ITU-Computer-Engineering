from datetime import datetime

from flask import current_app, render_template
from movie import Movie


def home_page():
    today = datetime.today()
    day_name = today.strftime("%A")
    return render_template("home.html", day=day_name)


def movies_page():
    myDB = current_app.config["dbconfig"]
    movies = myDB.get_movies()
    return render_template("movies.html", movies=sorted(movies))


def alter_movie(movie_id):
    myDB = current_app.config["dbconfig"]
    current_movie = myDB.get_movie(movie_id)
    new_movie_title = "Updated " + current_movie.title

    if current_movie.year != None:
        new_movie_year = current_movie.year + 100
        new_movie_object = Movie(new_movie_title, new_movie_year)
    else:
        new_movie_object = Movie(new_movie_title)

    myDB.update_movie(movie_id, new_movie_object)
    movies = myDB.get_movies()

    return render_template("movies.html", movies=sorted(movies))


def un_alter_movie(movie_id):
    myDB = current_app.config["dbconfig"]
    current_movie = myDB.get_movie(movie_id)
    new_movie_title = current_movie.title.replace("Updated", "")
    if current_movie.year != None:
        new_movie_year = current_movie.year - 100
        new_movie_object = Movie(new_movie_title, new_movie_year)
    else:
        new_movie_object = Movie(new_movie_title)

    myDB.update_movie(movie_id, new_movie_object)
    movies = myDB.get_movies()

    return render_template("movies.html", movies=sorted(movies))


def delete_movie(movie_id):
    myDB = current_app.config["dbconfig"]
    myDB.delete_movie(movie_id)
    movies = myDB.get_movies()


    return render_template("movies.html", movies=sorted(movies))