from flask import Flask

import views
from database import Database
from movie import Movie
import os

import sqlite3 as dbapi2

def create_app():
    app = Flask(__name__)
    app.config.from_object("settings")

    app.add_url_rule("/", view_func=views.home_page)   
    app.add_url_rule("/movies", view_func=views.movies_page) 
    app.add_url_rule("/alter_movie/<movie_id>", view_func=views.alter_movie)
    app.add_url_rule("/un_alter_movie/<movie_id>", view_func=views.un_alter_movie)

    ### TODO-1: ADD url rule for delete_movie function in the views.py
    app.add_url_rule("/delete_movie/<movie_id>", view_func=views.delete_movie)


    ###################################################################



    ##CREATE Database if not exist
    if(os.path.exists('./movies.db') ==False):

        con = dbapi2.connect("movies.db")
        print("Database is created and opened successfully")

        con.execute(
            "CREATE TABLE MOVIE ( ID INTEGER PRIMARY KEY AUTOINCREMENT, TITLE VARCHAR(80) NOT NULL,YR INTEGER)")

        print("Movie table is created successfully")

        con.close()

    home_dir = os.getcwd()

    ## REACH to the pre-created database

    db = Database(os.path.join(home_dir, "movies.db"))

    # db = Database()  # Database object is created.

    db.add_movie(Movie("Slaughterhouse-Five", year=1972))
    db.add_movie(Movie("The Shining")) 

    app.config["dbconfig"] = db  

    return app


if __name__ == "__main__":
    app = create_app()
    port = app.config.get("PORT", 5000)
    app.run(host="0.0.0.0", port=port)