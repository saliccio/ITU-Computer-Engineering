# 1-) CREATING DATA MODEL

class Movie:
    def __init__(self, title, year=None):
        self.title = title
        self.year = year